﻿
#include <iostream>
#include <string>
#include <stdexcept>
#include <map>
#include <cassert>
using namespace std;

template<typename T, int MAX = 10>
class Deque 
{
private:
    T arr[MAX]{};
    int front = -1;
    int rear = -1;

public:
    Deque() = default;

    void push_front(T item) 
    {
        if (isFull())
        {
            throw range_error("FULL !");
        }

        if (isEmpty()) 
        {
            front = rear = 0;
        }
        else
        {
            front = (front - 1 + MAX) % MAX;
        }

        arr[front] = item;
    }

    void push_rear(T item) 
    {
        if (isFull()) 
        {
            throw range_error("FULL !");
        }

        if (isEmpty()) 
        {
            front = rear = 0;
        }
        else 
        {
            rear = (rear + 1) % MAX;
        }

        arr[rear] = item;
    }

    void pop_front() 
    {
        if (isEmpty())
        {
            throw overflow_error("EMPTY !");
        }

        if (front == rear)
        {
            front = rear = -1;
        }
        else 
        {
            front = (front + 1) % MAX;
        }
    }

    void pop_rear() 
    {
        if (isEmpty())
        {
            throw overflow_error("EMPTY !");
        }

        if (front == rear) 
        {
            front = rear = -1;
        }
        else 
        {
            rear = (rear - 1 + MAX) % MAX;
        }
    }

    bool isFull() const 
    {
        return (front == 0 && rear == MAX - 1) || (front == rear + 1);
    }

    bool isEmpty() const 
    {
        return front == -1;
    }

    T getFront() const 
    {
        if (isEmpty()) 
        {
            throw runtime_error("EMPTY !");
        }

        return arr[front];
    }

    T getRear() const 
    {
        if (isEmpty()) 
        {
            throw runtime_error("EMPTY !");
        }

        return arr[rear];
    }
};

int main() {
    Deque<int> d1;

    d1.push_front(1);
    d1.push_rear(4);
    cout << "----- Before ----- " << endl;
    cout << "Front: " << d1.getFront() << endl;
    cout << "Rear: " << d1.getRear() << "\n\n";

    d1.pop_front();
    cout << "----- AFTER -----\n";
    cout << "Front: " << d1.getFront() << endl;
    cout << "Rear: " << d1.getRear() << endl; // 1 dene eded qaldigina gore Front ve Rear bir birine beraberdir.

    

}
